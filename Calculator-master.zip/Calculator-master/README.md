# **Calculator**

A bare minimum calculator app with following operations: addition, subtraction, multiplication, division, modulus.
(OOPS! This app can't handle exponent terms.)

# **Video**
![](src/calculator.gif)

# **Apk download**
[app-debug.apk](src/app-debug.apk?raw=true)

## **License**
Licensed under the [MIT License](LICENSE)
